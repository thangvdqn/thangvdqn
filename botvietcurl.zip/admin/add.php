<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8" />
<title>Add Token</title><center>
<form method="post">
<textarea rows="20" cols="100" type="text"  name="token" placeholder="Nhập Token vào đây ..."></textarea><br>
<select name="tab">
<option value="kuntoken" >Token Chạy Vip </option>
<option value="BotExLike" > Thêm Vào User Ex</option>
</select><br/>
<p><input class="btn btn-success" name="sub" type="submit" value="OK"/></p>
<h3>


<?php
require("../config.php");

if(isset($_POST['sub'])){
$token=$_POST['token'];
$table=$_POST['tab'];
$insert = $update = 0;
$data  = explode("\n", $token);

mysql_query("CREATE TABLE IF NOT EXISTS `kuntoken` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`user_id` varchar(32) NOT NULL,
`name` varchar(32) NOT NULL,
`access_token` varchar(255) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
");

foreach ($data as $token) {
$me = cek(trim($token));


if ($me['id']) {
if (mysql_num_rows(mysql_query("SELECT `name` FROM ".$table." WHERE user_id = '" . mysql_real_escape_string($me['id']) . "'"))) {
mysql_query("UPDATE ".$table." SET `access_token` = '" . mysql_real_escape_string($token) . "' WHERE `user_id` = " . $me['id'] . "");
++$insert;
} else {
mysql_query("INSERT INTO ".$table." SET
`user_id` = '" . mysql_real_escape_string($me['id']) . "',
`name` = '" . mysql_real_escape_string($me['name']) . "',
`access_token` = '" . mysql_real_escape_string($token) . "'
");
++$update;
}
}
}

echo 'INSERT ' . $insert;
echo '<br>UPDATE ' . $update;
}




function cek($o) {
return json_decode(auto('https://graph.facebook.com/me?access_token='.$o),true);
}

function auto($url) {
$ch = curl_init();
curl_setopt_array($ch, array(
CURLOPT_CONNECTTIMEOUT => 5,
CURLOPT_RETURNTRANSFER => true,
CURLOPT_URL            => $url,
)
);
$result = curl_exec($ch);
curl_close($ch);
return $result;
}

?>


</body>
</html>
