﻿<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<?php
$id = $_POST['id'];
$likemax = $_POST['likemax'];
$like = $_POST['like'];
include'../config.php';

$gettoken = mysql_query("SELECT * FROM `BotExLike` ORDER BY RAND() LIMIT 0,1");
$get = mysql_fetch_array($gettoken);

$token = $get['access_token'];
//check xem có token trong db ko
$namecheck = $get['name'];
if (!$token) {
die('Hết Token Để Check Rồi');
}
// xem token có life ko
$kiemtra = json_decode(file_get_contents('https://graph.facebook.com/me?access_token='.$token),true);
if (!$kiemtra['id']) {
mysql_query("DELETE FROM `BotExLike` WHERE `access_token` = '".$token."'");
die('Lỗi Token '.$namecheck.' Đã Die Hãy Ấn Lại Lần Nữa Để Chọn Token Khác');
}

// check id xem có life ko
$check = json_decode(file_get_contents('https://graph.facebook.com/'.$id.'/?access_token='.$token),true);
if (!$check['id']) {
die('ID ko tồn tại');
}else {
$name = $check['name'];
}

// kết nối
$connection = mysql_connect($host,$username,$password);
if (!$connection)
  {
  die('Could not connect: ' . mysql_error());
  }


mysql_select_db($dbname) or die(mysql_error());
mysql_query("SET NAMES utf8");
mysql_query("CREATE TABLE IF NOT EXISTS `vip` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `user_id` varchar(32) NOT NULL,
      `name` varchar(32) NOT NULL,
      `likemax` varchar(32) NOT NULL,
      `like` varchar(32) NOT NULL,
      PRIMARY KEY (`id`)
      ) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
   ");

    $result = mysql_query("
      SELECT
         *
      FROM
         vip
      WHERE
         user_id = '" . $check['id'] . "'
   ");

   if($result){
      $row = mysql_fetch_array($result, MYSQL_ASSOC);

      if($row){
        die('ID Này đã Có Trên Hệ Thống');
      }else {
      mysql_query(
         "INSERT INTO 
            vip
         SET
            `user_id` = '" .$check['id']. "',
            `name` = '" . $name. "',
            `likemax` = '" . $likemax. "',
            `like` = '".$like."'
      ");
echo 'Đã Thêm User '.$name;
   }
}
// thành công cmnr





?>