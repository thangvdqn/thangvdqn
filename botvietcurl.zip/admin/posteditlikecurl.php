<?php
include'../config.php';
$id = $_POST['id'];
$like = $_POST['likemax'];
if($like <=9) {
die('Số Like Không Được Nhỏ Hơn 10');
}

// kết nối
$connection = mysql_connect($host,$username,$password);
if (!$connection)
  {
  die('Could not connect: ' . mysql_error());
  }


mysql_select_db($dbname) or die(mysql_error());

    $result = mysql_query("
      SELECT
         *
      FROM
         curl
      WHERE
         user_id = '" . $id . "'
   ");

   if($result){
      $row = mysql_fetch_array($result, MYSQL_ASSOC);

      if($row){
mysql_query(

"UPDATE
curl
SET
`likemax` = '" . $like . "'

WHERE

`user_id` = " . $id . "

");
       echo ' Đã Cập Nhật Like<br>Cho User '.$id;
      }else {
echo 'User '.$id.' Chưa Đăng Kí Vip <br>Trên Hệ Thống';
   }
}
// thành công cmnr





?>