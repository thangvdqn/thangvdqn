<?php
$id = $_POST['id'];
$likemax = $_POST['likemax'];
$cookie = $_POST['cookie'];
include'../config.php';
$token = file_get_contents($dm.'/htc.php?cookie='.urlencode($cookie));
if(!$token) {
die('Cookie Này Không Hợp Lệ<br>Hoặc Chưa Cài HTC');
}


// check id xem có life ko
$check = json_decode(file_get_contents('https://graph.facebook.com/'.$id.'/?access_token='.$token),true);
if (!$check['id']) {
die('ID ko tồn tại');
}else {
$name = $check['name'];
}

// kết nối
$connection = mysql_connect($host,$username,$password);
if (!$connection)
  {
  die('Could not connect: ' . mysql_error());
  }


mysql_select_db($dbname) or die(mysql_error());
mysql_query("SET NAMES utf8");
mysql_query("CREATE TABLE IF NOT EXISTS `curl` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `user_id` varchar(32) NOT NULL,
      `name` varchar(32) NOT NULL,
      `likemax` varchar(32) NOT NULL,
      `trangthai` varchar(32) NOT NULL,
      `cookie` varchar(9999) NOT NULL,
      PRIMARY KEY (`id`)
      ) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
   ");

    $result = mysql_query("
      SELECT
         *
      FROM
         curl
      WHERE
         user_id = '" . $check['id'] . "'
   ");

   if($result){
      $row = mysql_fetch_array($result, MYSQL_ASSOC);

      if($row){
        die('ID Này đã Có Trên Hệ Thống');
      }else {
      mysql_query(
         "INSERT INTO 
            curl
         SET
            `user_id` = '" .$check['id']. "',
            `name` = '" . $name. "',
            `trangthai` = 'Live',
            `likemax` = '" . $likemax. "',
            `cookie` = '".$cookie."'
      ");
echo 'Đã Thêm User '.$name;
   }
}
// thành công cmnr





?>