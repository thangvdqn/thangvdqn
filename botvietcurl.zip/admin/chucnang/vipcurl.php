<div class="input-group">
      <input type="text" id="id" class="form-control" placeholder="Nhập ID User Vip">
      <input type="text" id="cookie" class="form-control" placeholder="Nhập Cookie Clone">
      <input type="number" id="likemax" class="form-control" placeholder="Nhập Số Lượng Like Max">

    </div>
      <span class="input-group-btn">
<center>
        <button class="btn btn-danger" id="addvip" onclick="addvip()" title="Add User"> Add User</button>
      </span>





<!-- ÂDD VIP-->
 <script language="javascript">

function addvip() {
if(!$('#id').val()) {
alert("Hãy Nhập ID User Vip");
}else if(!$('#cookie').val()) {
alert("Hãy Nhập Cookie Của Clone");
}else if(!$('#likemax').val()) {
alert("Hãy Nhập Số Lượng Like Max cho User Này");
}else {
addvipxuly();
}
}

   function addvipxuly(){
     $('#addvip').html('<i class="fa fa-spinner fa-spin"></i> Đang Xử Lý');
                $.ajax({
                    url : "postvipcurl.php",
                    type : "post",
                    dateType:"text",
                    data : {
                         id : $('#id').val(), cookie : $('#cookie').val(), likemax : $('#likemax').val()
                    },
                    success : function (result){
                        $('#addvip').html(result);
                    }
                });
}


</script>