<div class="input-group">
      <input type="text" id="id" class="form-control" placeholder="Nhập ID User Vip">
      <input type="number" id="likemax" class="form-control" placeholder="Nhập Số Lượng Like Max">
      <input type="number" id="like" class="form-control" placeholder="Nhập 1 Nếu Muốn Like Cmt, 2 Là Không">
    </div>
      <span class="input-group-btn">
<center>
        <button class="btn btn-danger" id="addvip" onclick="addvip()" title="Add User"> Add User</button>
      </span>





<!-- ÂDD VIP-->
 <script language="javascript">

function addvip() {
if(!$('#id').val()) {
alert("Hãy Nhập ID User Vip");
}else if(!$('#likemax').val()) {
alert("Hãy Nhập Số Lượng Like Max cho User Này");
}else if(!$('#like').val()) {
alert("Hãy Nhập Like Comment");
}else  if($('#like').val() == '1' || $('#like').val() == '2') {
addvipxuly();
}else {
alert("Hãy Nhập 1 Nếu Muốn Like Cmt, 2 Là Không")
}
}

   function addvipxuly(){
     $('#addvip').html('<i class="fa fa-spinner fa-spin"></i> Đang Xử Lý');
                $.ajax({
                    url : "postvip.php",
                    type : "post",
                    dateType:"text",
                    data : {
                         id : $('#id').val(), like : $('#like').val(), likemax : $('#likemax').val()
                    },
                    success : function (result){
                        $('#addvip').html(result);
                    }
                });
}


</script>
