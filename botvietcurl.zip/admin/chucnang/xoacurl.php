<div class="input-group">
      <input type="text" id="xoa" class="form-control" placeholder="Nhập ID Muốn Xóa Vip Curl">
    </div>
      <span class="input-group-btn">
<center>
        <button class="btn btn-danger" id="addvip" onclick="addlike()" title="Add User"> Xóa User</button>
      </span>





<!-- ÂDD VIP-->
 <script language="javascript">

function addlike() {
if(!$('#xoa').val()) {
alert("Hãy Nhập ID Muốn Xóa Vip Curl");
}else {
addvipxuly();
}
}

   function addvipxuly(){
     $('#addvip').html('<i class="fa fa-spinner fa-spin"></i> Đang Xử Lý');
                $.ajax({
                    url : "postxoacurl.php",
                    type : "post",
                    dateType:"text",
                    data : {
                         id : $('#xoa').val()
                    },
                    success : function (result){
                        $('#addvip').html(result);
                    }
                });
}


</script>