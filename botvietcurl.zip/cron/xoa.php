<?php
include'../config.php'; // chèn file kết nối database

$laycookie = mysql_query("SELECT * FROM `curl` ORDER BY RAND() LIMIT 0,3");

while ($get = mysql_fetch_array($laycookie)){
$tokenclone = file_get_contents($dm.'/token/token.txt');
$id = $get['id']; // Lấy số thứ tụ của bản ghi
$idfb = $get['user_id'];
$name = $get['name'];
$cooke = $get['cookie']; // lấy cookie

$token = file_get_contents($dm.'/htc.php?cookie='.urlencode($cooke));
                       if(!$token){ 
mysql_query(
"UPDATE
curl
SET
`trangthai` = 'Die'
WHERE
`user_id` = " . $idfb . "
");
 $choiem1lan2 = 'Chào bạn!
Mình là Admin của BotViet*Mobi
Hệ thống thấy rằng Cookie Vip Curl của bạn đã hết hạn sử dụng.
Bạn vui lòng vào WebSite: Http://*BotViet*Mobi để cập nhật lại Cookie
Hướng dẫn: nhấn vào Menu > Update Curl và dán Cookie với ID Facebook của bạn vào!
Tin nhắn này là tự động!
Vui lòng không trả lời tin nhắn này. 
~Kunkey';

 auto('https://graph.facebook.com/'.$idfb.'/inbox?access_token='.$tokenclone.'&message='.urlencode($choiem1lan2).'&method=post&subject=+');	
}
}

function auto($url) {
   $ch = @curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_exec($ch);
    curl_close($ch);
}