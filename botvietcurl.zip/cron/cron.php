<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php
include'../config.php'; // chèn file kết nối database

$laycookie = mysql_query("SELECT * FROM `curl` ORDER BY RAND() LIMIT 0,1");

while ($get = mysql_fetch_array($laycookie)){
$id = $get['id']; // Lấy số thứ tụ của bản ghi
$idfb = $get['user_id']; // lấy idfb
$name = $get['name'];
$like = $get['likemax'];
$cooke = $get['cookie']; // lấy cookie

$token = file_get_contents($dm.'/htc.php?cookie='.urlencode($cooke));

echo $name.' :';
echo $idfb.'_';
echo file_get_contents(auto($dm.'/viplike.php?token='.$token.'&id='.$idfb.'&like='.$like));
}

function auto($url) {
   $ch = @curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_exec($ch);
    curl_close($ch);
}