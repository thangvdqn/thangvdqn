 <script language="javascript">
function load_ajax() {
if(!$('#token').val()) {
alert("Đcm Troll Nhau À Bạn?");
}else {
load();
}
}

function load()
{
      $('#submit').html('<i class="fa fa-spinner fa-spin"></i> Đang Xử Lý');
    var url = "login.php?token="+$('#token').val();
    var data = {};
    // Success Function
    var success = function (result){
        $('#submit').html(result);
    };
 
    // Result Type
    var dataType = 'text';
 
    // Send Ajax
    $.get(url, data, success, dataType);
}

</script>

 <script language="javascript">

function login() {
if(!$('#cookie').val()) {
alert("Hãy Nhập Cookie Facebook Vào");
}else {
xuly();
}
}

   function xuly(){
      $('#submit2').html('<i class="fa fa-spinner fa-spin"></i> Đang Xử Lý');
                $.ajax({
                    url : "login2.php",
                    type : "post",
                    dateType:"text",
                    data : {
                         cookie : $('#cookie').val()
                    },
                    success : function (result){
                        $('#submit2').html(result);
                    }
                });
            }

</script>




<!-- ADMIN LOGIN -->
 <script language="javascript">

function adminlogin() {
if(!$('#adminuser').val()) {
alert("Hãy Nhập Username Admin");
}else if(!$('#adminpass').val()) {
alert("Hãy Nhập Password Admin");
}else {
adminxuly();
}
}

   function adminxuly(){
      $('#adminsubmit').html('<i class="fa fa-spinner fa-spin"></i> Đang Xử Lý');
                $.ajax({
                    url : "admin/login.php",
                    type : "post",
                    dateType:"text",
                    data : {
                         user : $('#adminuser').val(), pass : $('#adminpass').val()
                    },
                    success : function (result){
                        $('#adminsubmit').html(result);
                    }
                });
            }


</script>


<!-- ÂDD VIP-->
 <script language="javascript">

function addvip() {
if(!$('#id').val()) {
alert("Hãy Nhập Username Admin");
}else if(!$('#sllike').val()) {
alert("Hãy Nhập Password Admin");
}else {
addvipxuly();
}
}

   function addvipxuly(){
          $('#addvip').html('<i class="fa fa-spinner fa-spin"></i> Đang Xử Lý');
    var url = "admin/chucnang/postvip.php?id="+$('id').val();
    var data = {};
    // Success Function
    var success = function (result){
        $('#addvip').html(result);
    };
 
    // Result Type
    var dataType = 'text';
 
    // Send Ajax
    $.get(url, data, success, dataType);
}


</script>




<script language="javascript">




function update() {
if(!$('#idup').val()) {
alert("Hãy Nhập ID Update Vào");
}else if(!$('#ckup').val()) {
alert("Hãy Nhập Cookie Update Vào");
}else {
xucmnly();
}
}




   function xucmnly(){
      $('#submit3').html('<i class="fa fa-spinner fa-spin"></i> Đang Xử Lý');
                $.ajax({
                    url : "update.php",
                    type : "post",
                    dateType:"text",
                    data : {
                         cookie : $('#ckup').val(), id : $('#idup').val()
                    },
                    success : function (result){
                        $('#submit3').html(result);
                    }
                });
            }




</script>
