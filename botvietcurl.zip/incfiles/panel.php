<?php if(($_SESSION['id'])) {
print '<!-- Modal -->
<div class="modal fade" id="bat" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"> Xác Nhận Bật Bot</h4>
      </div>
      <div class="modal-body">
<form method="post" action="xuly.php?access_token='.$_SESSION['access_token'].'">
<h5> BẠN CÓ MUỐN BẬT BOT EXLIKE ?</h5>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
        <button type="submit" id="batbot" onclick="batbot()" class="btn btn-primary">Xác nhận</button>
      </div>
    </div>
  </div>
</div>';
}else{
print'<!-- Modal -->';}?>


<!-- Modal -->
<div class="modal fade" id="huongdan" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Giới thiệu hệ thống</h4>
      </div>
      <div class="modal-body">
<p>
Lưu ý: Bạn nên trên 18 tuổi, nếu không hãy <a href="https://www.facebook.com/me/about?section=contact-info&pnref=about" target="_blank" class="text-warning"> <b>thay đổi năm sinh </b></a> thành trên 18 tuổi. Nếu không sẽ không bật theo giõi được</p> 
<p>
Đầu tiên, bạn click vào <a href="https://www.facebook.com/settings?tab=followers" target="_blank"  class="text-warning"><b>đây</b></a> để thay đổi thiết lập người theo giõi. Trong phần: "<b>Ai có thể theo dõi tôi</b>" bạn chọn và sửa thành <span class="label label-warning"><i class="glyphicon glyphicon-globe"></i> Tất cả mọi người</span></p><p>
		Tiếp theo phần: "<b>Bình luận của người theo dõi</b>" bạn chọn và sửa thành:  <span class="label label-warning"> <i class="glyphicon glyphicon-globe"></i> Tất cả mọi người </span>
</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="gioithieu" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"> Update Cookie Cho Curl Like</h4>
      </div>
      <div class="modal-body">
<p><b>Warning!</b> Chỉ dành cho Vip Curl Member.
<br/>

<center>
<div class="input-group">
      <input type="text" id="idup" class="form-control" placeholder="Nhập ID Vip Curl vô đây">
      <input type="text" id="ckup" class="form-control" placeholder="Nhập Cookie Facebook của bạn vô đây">
</div>
      <span class="input-group-btn">
        <button class="btn btn-danger" id="submit3" onclick="update()" title="Cập Nhật"> Cập Nhật</button>
      </span>
   </center>





</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
        <!--<button type="button" class="btn btn-primary">Xác nhận</button>-->
      </div>
    </div>
  </div>
</div>








<!-- Modal -->
<div class="modal fade" id="muavip" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"> Bảng Giá Vip Like</h4>
      </div>
      <div class="modal-body">

<table class="table table-bordered"><b>
<thead>
<tr>
<th> Số Like</th>
<th>Phí Theo Tháng</th>
</tr>
</thead>
<tbody>
<tr>
<td>500 like</td>
<td>50k</td>
<tr>
<td>1000 like</td>
<td>100k</td>
</tr>
<tr>
<td>2000 like</td>
<td>150k</td>
</tr>
<tr>
<td>3000 like</td>
<td>200k</td>
</tr>
<td>4000 like</td>
<td>250k</td>
</tr>
<td>5000 like</td>
<td>300k</td>
</tr>
<td>6000 like </td>
<td>350k</td>
</tr>
</tbody>
</table>



      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
        <!--<button type="button" class="btn btn-primary">Xác nhận</button>-->
      </div>
    </div>
  </div>
</div>