<div class="panel-heading"><i class="fa fa-user"></i> <b> Cách 1: Đăng nhập bằng Token</b></div>
<div class="panel-body">

<div class="row">
  <div class="col-lg-6">
    <div class="input-group">
      <input type="text" id="token" class="form-control" placeholder="Nhập Mã Token Của Bạn Vào Đây">
      <span class="input-group-btn">
        <button class="btn btn-danger" id="submit" onclick="load_ajax()" title="Đăng nhập"> Đăng Nhập</button>
      </span>
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->
</div><!-- /.row -->

</div>
<center><a href="https://developers.facebook.com/tools/debug/accesstoken/?app_id=41158896424" target="_blank" class="btn btn-success"> Lấy Token</a> <a href="http://botviet.net/gettoken/htc.php" target="_blank" class="btn btn-info"> Cài Đặt Token</a> </center> 